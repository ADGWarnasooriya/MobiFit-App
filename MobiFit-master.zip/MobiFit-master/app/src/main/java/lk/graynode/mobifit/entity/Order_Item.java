package lk.graynode.mobifit.entity;

public class Order_Item {
    public Order_Item() {

    }

    private String p_name;
    private String p_qty_price;
    private String p_tot;





    private String url;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getP_name() {
        return p_name;
    }

    public void setP_name(String p_name) {
        this.p_name = p_name;
    }

    public String getP_qty_price() {
        return p_qty_price;
    }

    public void setP_qty_price(String p_qty_price) {
        this.p_qty_price = p_qty_price;
    }

    public String getP_tot() {
        return p_tot;
    }

    public void setP_tot(String p_tot) {
        this.p_tot = p_tot;
    }
}
